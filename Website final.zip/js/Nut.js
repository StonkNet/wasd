function myFunction() {
  alert("YOU ARE A SUSSY BAKA!");
}